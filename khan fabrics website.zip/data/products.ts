
import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: 'kf-ns-1',
    name: 'Noor-e-Sard Long Wool Shirt',
    price: 42000,
    category: 'Wool',
    collection: 'Noor-e-Sard',
    image: 'https://images.unsplash.com/photo-1539106609512-300435161049?q=80&w=800&auto=format&fit=crop',
    description: 'Light of Winter edit. Elegant long-line shirt in soft-spun wool with delicate neckline embroidery.'
  },
  {
    id: 'kf-zw-1',
    name: 'Zamurd Emerald Pashmina',
    price: 95000,
    category: 'Pashmina',
    collection: 'Zamurd Winter Grace',
    image: 'https://images.unsplash.com/photo-1610030469614-2795c69748b6?q=80&w=800&auto=format&fit=crop',
    description: 'Emerald elegance. Hand-woven Pashmina shawl paired with a minimalist silk-wool suit.'
  },
  {
    id: 'kf-rz-1',
    name: 'Riwayat Traditional Kurta',
    price: 35000,
    category: 'Linen-Wool',
    collection: 'Riwayat-e-Zanana',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=800&auto=format&fit=crop',
    description: 'Women’s winter tradition. Classic Pakistani cut in heavy linen-wool with heritage cross-stitch detail.'
  },
  {
    id: 'kf-ss-1',
    name: 'Sardiyaan Minimal Blazer',
    price: 58000,
    category: 'Wool',
    collection: 'Sardiyaan Silhouettes',
    image: 'https://images.unsplash.com/photo-1543076447-215ad9ba6923?q=80&w=800&auto=format&fit=crop',
    description: 'Winter shapes. Modern structured blazer in soft wool, tailored for the young professional.'
  },
  {
    id: 'kf-vk-1',
    name: 'Velour Khawab Gala Set',
    price: 165000,
    category: 'Velvet',
    collection: 'Velour Khawab',
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=800&auto=format&fit=crop',
    description: 'Velvet dreams. Premium deep-pile velvet gown with a heavy Pashmina dupatta.'
  },
  {
    id: 'kf-ns-2',
    name: 'Noor Linen-Wool Co-ord',
    price: 38000,
    category: 'Linen-Wool',
    collection: 'Noor-e-Sard',
    image: 'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?q=80&w=800&auto=format&fit=crop',
    description: 'Lightweight linen-wool blend co-ord set. Breathable warmth for daily winter errands.'
  },
  {
    id: 'kf-zw-2',
    name: 'Maroon Velvet Event Wrap',
    price: 48000,
    category: 'Velvet',
    collection: 'Zamurd Winter Grace',
    image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=800&auto=format&fit=crop',
    description: 'Rich maroon velvet shawl with intricate gold Tilla work on the borders.'
  },
  {
    id: 'kf-vk-2',
    name: 'Royal Plum Velour Tunic',
    price: 72000,
    category: 'Velvet',
    collection: 'Velour Khawab',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=800&auto=format&fit=crop',
    description: 'Luxury formal wear in high-sheen velvet, featuring architectural sleeves.'
  }
];

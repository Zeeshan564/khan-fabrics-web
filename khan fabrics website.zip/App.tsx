import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Cart } from './components/Cart';
import { StylistAI } from './components/StylistAI';
import { PRODUCTS } from './data/products';
import { Product, CartItem } from './types';

const App: React.FC = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('Winter');

  // Trigger AdSense pushes after component mounts
  useEffect(() => {
    const pushAds = () => {
      try {
        // We push once for each ad unit on the page
        // @ts-ignore
        (window.adsbygoogle = window.adsbygoogle || []).push({});
        // @ts-ignore
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (e) {
        console.error("AdSense initialization error:", e);
      }
    };
    
    const timer = setTimeout(pushAds, 500);
    return () => clearTimeout(timer);
  }, []);

  const filteredProducts = activeCategory === 'Winter' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategory);

  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#fafafa] text-gray-900 selection:bg-[#581819] selection:text-white">
      <Navbar cartCount={cartCount} onCartClick={() => setIsCartOpen(true)} />
      <Cart 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cartItems} 
        onRemove={removeFromCart} 
      />
      
      {/* Hero Section */}
      <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1445205170230-053b83016050?q=80&w=1920&auto=format&fit=crop" 
            alt="Khan Fabrics Hero" 
            className="w-full h-full object-cover brightness-[0.45] transition-transform duration-[20s] hover:scale-105"
          />
        </div>
        <div className="relative z-10 text-center text-white px-4">
          <div className="mb-8 flex justify-center items-center gap-6 opacity-80">
             <div className="w-12 h-[1px] bg-[#C5A059]" />
             <span className="text-[10px] tracking-[0.6em] uppercase font-bold text-[#C5A059]">Noor-e-Sard Collection</span>
             <div className="w-12 h-[1px] bg-[#C5A059]" />
          </div>
          <h1 className="text-6xl md:text-9xl font-serif font-bold mb-6 tracking-tighter leading-tight">
            KHAN FABRICS
          </h1>
          <p className="max-w-xl mx-auto mb-12 text-sm md:text-lg font-light tracking-[0.3em] opacity-90 uppercase">
            Where Winter Meets Grace
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="#shop" 
              className="px-12 py-5 bg-[#581819] text-white text-[10px] font-bold tracking-[0.4em] hover:bg-[#1A3C34] transition-all duration-500 shadow-2xl"
            >
              SHOP WINTER EDIT
            </a>
            <a 
              href="#collections" 
              className="px-12 py-5 border border-white/30 backdrop-blur-md text-white text-[10px] font-bold tracking-[0.4em] hover:bg-white hover:text-black transition-all duration-500"
            >
              VIEW COLLECTIONS
            </a>
          </div>
        </div>
      </section>

      {/* Collection Highlights */}
      <section id="collections" className="py-32 container mx-auto px-6">
        <div className="text-center mb-24">
          <span className="text-[10px] tracking-[0.6em] font-bold text-[#581819] uppercase block mb-4">Five Pillars of Winter</span>
          <h2 className="text-5xl font-serif font-bold text-[#1A3C34]">The Signature Series</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
           {[
             { name: 'Noor-e-Sard', desc: 'Light of Winter', color: 'bg-white' },
             { name: 'Zamurd Grace', desc: 'Emerald Elegance', color: 'bg-[#1A3C34]' },
             { name: 'Riwayat-e-Zanana', desc: 'Women’s Tradition', color: 'bg-[#581819]' },
             { name: 'Sardiyaan', desc: 'Modern Silhouettes', color: 'bg-gray-200' },
             { name: 'Velour Khawab', desc: 'Velvet Dreams', color: 'bg-black' }
           ].map((col) => (
             <div key={col.name} className="group relative aspect-[3/4] overflow-hidden cursor-pointer shadow-sm">
                <div className={`absolute inset-0 ${col.color} opacity-10`} />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10">
                   <h4 className="text-lg font-serif font-bold mb-1 transition-all group-hover:-translate-y-2">{col.name}</h4>
                   <p className="text-[9px] tracking-widest uppercase text-gray-400 opacity-0 group-hover:opacity-100 transition-all duration-500">{col.desc}</p>
                   <div className="mt-4 w-8 h-[1px] bg-[#C5A059] group-hover:w-16 transition-all duration-500" />
                </div>
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-[#C5A059]/20 transition-all duration-500 m-2" />
             </div>
           ))}
        </div>
      </section>

      {/* Ad Section - Mid Page */}
      <section className="py-12 bg-white container mx-auto px-6 flex justify-center border-b border-gray-50 overflow-hidden">
        <div className="w-full max-w-4xl text-center">
          <p className="text-[8px] tracking-[0.4em] uppercase text-gray-300 mb-4">Advertisement</p>
          <ins className="adsbygoogle"
               style={{ display: 'block' }}
               data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
               data-ad-slot="1234567890"
               data-ad-format="auto"
               data-full-width-responsive="true"></ins>
        </div>
      </section>

      {/* Product Feed */}
      <section id="shop" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-20 gap-8">
            <div className="space-y-4">
              <h2 className="text-5xl font-serif font-bold tracking-tight text-[#1A3C34]">Khan Fabrics <span className="text-gray-200">/</span> Winter '25</h2>
              <p className="text-[10px] tracking-[0.4em] text-[#C5A059] font-bold uppercase">Women Winter Wear Edition</p>
            </div>
            <div className="flex flex-wrap gap-8 text-[10px] font-bold tracking-[0.3em] uppercase border-b border-gray-100 pb-4 w-full md:w-auto overflow-x-auto">
              {['Winter', 'Wool', 'Pashmina', 'Velvet', 'Linen-Wool'].map(cat => (
                <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`pb-4 px-1 transition-all duration-300 relative whitespace-nowrap ${activeCategory === cat ? 'text-[#581819]' : 'text-gray-300 hover:text-gray-500'}`}
                >
                  {cat}
                  {activeCategory === cat && <div className="absolute bottom-[-1.5px] left-0 right-0 h-[3px] bg-[#581819]" />}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-24">
            {filteredProducts.map((product) => (
              <div key={product.id} className="group cursor-pointer">
                <div className="relative aspect-[3/4] bg-gray-50 mb-6 overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  />
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    <span className="bg-[#581819] text-white px-3 py-1 text-[8px] font-bold tracking-widest uppercase shadow-lg">
                      {product.collection}
                    </span>
                    <span className="bg-white/90 backdrop-blur-sm text-[#1A3C34] px-3 py-1 text-[8px] font-bold tracking-widest uppercase shadow-sm">
                      Premium {product.category}
                    </span>
                  </div>
                  <button 
                    onClick={() => addToCart(product)}
                    className="absolute bottom-0 left-0 right-0 bg-[#1A3C34] text-white text-[10px] font-bold tracking-[0.4em] py-5 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-500 uppercase"
                  >
                    ADD TO BAG
                  </button>
                </div>
                <div className="space-y-3 px-1">
                  <div className="flex justify-between items-baseline">
                    <h3 className="text-[11px] font-bold tracking-[0.1em] uppercase group-hover:text-[#581819] transition-colors">{product.name}</h3>
                    <p className="text-sm font-medium text-gray-800">Rs. {product.price.toLocaleString()}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-1 h-1 rounded-full bg-[#C5A059]" />
                    <p className="text-[9px] text-gray-400 uppercase tracking-widest font-bold">
                      {product.category === 'Pashmina' ? 'Pashmina Heritage Touch' : 
                       product.category === 'Velvet' ? 'Luxury Velour Finish' :
                       'Pure Wool Blend'}
                    </p>
                  </div>
                  <p className="text-[10px] text-gray-500 font-light leading-relaxed line-clamp-2 italic">{product.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brand Ethos */}
      <section className="py-32 bg-[#1A3C34] text-white overflow-hidden">
        <div className="container mx-auto px-6 grid md:grid-cols-2 gap-20 items-center">
           <div className="space-y-12">
              <span className="text-[10px] tracking-[0.6em] font-bold text-[#C5A059] uppercase">The Brand Philosophy</span>
              <h2 className="text-5xl md:text-7xl font-serif font-bold leading-tight">Tradition. <br />Warmth. <br />Style.</h2>
              <p className="text-lg opacity-70 font-light italic leading-relaxed max-w-md">
                "We strip away the noise to reveal the grace of the thread. Every piece is a dialogue between heritage weaves and modern silhouettes."
              </p>
              <div className="pt-8 grid grid-cols-2 gap-8 border-t border-white/10">
                 <div>
                    <h4 className="text-[#C5A059] text-[10px] font-bold tracking-widest uppercase mb-2">Artisan Made</h4>
                    <p className="text-[11px] opacity-60">Hand-spun Khaddar and hand-woven Pashmina from our local ateliers.</p>
                 </div>
                 <div>
                    <h4 className="text-[#C5A059] text-[10px] font-bold tracking-widest uppercase mb-2">Winter Formal</h4>
                    <p className="text-[11px] opacity-60">Specialized Velvet collections for the Pakistani wedding season.</p>
                 </div>
              </div>
           </div>
           <div className="relative">
              <div className="aspect-[4/5] bg-white/5 p-4 border border-white/10">
                 <img 
                    src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=800&auto=format&fit=crop" 
                    className="w-full h-full object-cover grayscale brightness-75 hover:grayscale-0 transition-all duration-1000"
                    alt="Brand Legacy"
                 />
              </div>
              <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-[#581819] flex items-center justify-center p-8 text-center shadow-2xl">
                 <span className="text-[10px] font-bold tracking-[0.4em] uppercase border-b border-white/20 pb-2">Crafting Warmth for Her</span>
              </div>
           </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-32 border-t border-gray-100">
        <div className="container mx-auto px-6">
          <div className="flex flex-col items-center mb-24 text-center">
             <div className="mb-6">
                <span className="text-5xl md:text-7xl font-serif font-bold tracking-[0.2em] text-[#1A3C34]">KHAN FABRICS</span>
                <div className="h-[2px] w-32 bg-[#C5A059] mx-auto mt-4" />
             </div>
             <p className="text-[11px] tracking-[0.8em] text-[#581819] uppercase font-bold">Luxury Winter Wear for Her</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-20">
            <div>
              <h4 className="font-bold text-[10px] tracking-[0.4em] uppercase text-gray-400 mb-8">Quick Links</h4>
              <ul className="space-y-4 text-xs font-bold tracking-[0.2em] uppercase text-gray-800">
                <li><a href="#collections" className="hover:text-[#581819] transition-colors">Internal URL: /collections</a></li>
                <li><a href="#shop" className="hover:text-[#581819] transition-colors">Internal URL: /atelier-shop</a></li>
                <li><a href="/" className="hover:text-[#581819] transition-colors">Home Archive</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[10px] tracking-[0.4em] uppercase text-gray-400 mb-8">Collections</h4>
              <ul className="space-y-4 text-xs font-bold tracking-[0.2em] uppercase text-gray-800">
                <li><a href="#" className="hover:text-[#581819] transition-colors">Noor-e-Sard</a></li>
                <li><a href="#" className="hover:text-[#581819] transition-colors">Zamurd Grace</a></li>
                <li><a href="#" className="hover:text-[#581819] transition-colors">Riwayat-e-Zanana</a></li>
                <li><a href="#" className="hover:text-[#581819] transition-colors">Velour Khawab</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[10px] tracking-[0.4em] uppercase text-gray-400">Concierge</h4>
              <ul className="space-y-4 text-xs font-bold tracking-[0.2em] uppercase text-gray-800">
                <li><a href="#" className="hover:text-[#581819] transition-colors">Custom Tailoring</a></li>
                <li><a href="#" className="hover:text-[#581819] transition-colors">Worldwide Shipping</a></li>
                <li><a href="#" className="hover:text-[#581819] transition-colors">Care Guide</a></li>
              </ul>
            </div>
            <div className="md:col-span-1">
              <h4 className="font-bold text-[10px] tracking-[0.4em] uppercase text-gray-400 mb-8">Journal</h4>
              <p className="text-xs text-gray-400 mb-8 leading-relaxed uppercase tracking-widest">Sign up for early access.</p>
              <form className="flex border-b border-gray-200 pb-2">
                <input 
                  type="email" 
                  placeholder="ENTER YOUR EMAIL" 
                  className="bg-transparent text-[10px] font-bold py-2 flex-1 focus:outline-none placeholder:text-gray-200 tracking-[0.2em]"
                />
                <button type="submit" className="text-[10px] font-bold tracking-[0.3em] hover:text-[#581819] transition-colors">JOIN</button>
              </form>
            </div>
          </div>

          {/* Footer Ad Unit */}
          <div className="py-12 border-t border-gray-50 flex justify-center">
            <ins className="adsbygoogle"
                 style={{ display: 'block' }}
                 data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
                 data-ad-slot="1234567890"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
          </div>
          
          <div className="pt-20 border-t border-gray-50 flex flex-col md:flex-row justify-between items-center gap-6 text-[9px] text-gray-300 uppercase tracking-[0.4em] font-bold">
            <p>&copy; 2025 KHAN FABRICS | LUXURY BOUTIQUE ARCHIVE.</p>
            <div className="flex gap-12">
              <a href="https://instagram.com/khanfabrics" className="hover:text-black">External: Instagram</a>
              <a href="#" className="hover:text-black">Pinterest</a>
              <a href="#" className="hover:text-black">Lahore, PK</a>
            </div>
          </div>
        </div>
      </footer>

      <StylistAI />
    </div>
  );
};

export default App;
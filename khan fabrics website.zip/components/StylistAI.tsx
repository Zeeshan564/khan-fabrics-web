
import React, { useState, useRef, useEffect } from 'react';
import { getStylingAdvice } from '../services/geminiService';
import { ChatMessage } from '../types';

export const StylistAI: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Welcome to the KHAN FEBRICE atelier. I can search for global trends or assist with our local winter archives. What may I find for you?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    const result = await getStylingAdvice(messages, userMessage);
    setMessages(prev => [...prev, { role: 'model', text: result.text, sources: result.sources }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-[#1A3C34] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform duration-300 flex items-center gap-2 group"
        >
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 whitespace-nowrap text-[10px] tracking-widest font-bold uppercase">Ask Stylist</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/><path d="M12 4v16"/><path d="m14 8-2-2-2 2"/><path d="m14 16-2 2-2-2"/></svg>
        </button>
      )}

      {isOpen && (
        <div className="bg-white w-80 md:w-96 h-[550px] shadow-2xl rounded-2xl flex flex-col overflow-hidden border border-gray-100 animate-fade-in">
          <div className="bg-[#1A3C34] text-white p-5 flex justify-between items-center">
            <div className="flex flex-col">
              <h3 className="font-serif text-lg tracking-tight">KHAN AI STYLIST</h3>
              <span className="text-[8px] tracking-[0.3em] uppercase opacity-60">Grounded in Web Research</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:opacity-70 transition-opacity">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-6 bg-gray-50/50">
            {messages.map((m, i) => (
              <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl text-xs leading-relaxed ${
                  m.role === 'user' 
                    ? 'bg-[#581819] text-white rounded-br-none shadow-md' 
                    : 'bg-white border border-gray-100 text-gray-800 rounded-bl-none shadow-sm'
                }`}>
                  {m.text}
                </div>
                
                {m.sources && m.sources.length > 0 && (
                  <div className="mt-3 w-[90%] space-y-2">
                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest px-2">Sources Found:</p>
                    <div className="flex flex-col gap-2">
                      {m.sources.map((src, idx) => (
                        <a 
                          key={idx} 
                          href={src.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="bg-white border border-gray-100 p-3 rounded-xl flex items-center justify-between hover:border-[#C5A059] transition-all group shadow-sm"
                        >
                          <div className="flex flex-col overflow-hidden pr-4">
                            <span className="text-[10px] font-bold text-gray-800 truncate mb-1">{src.title}</span>
                            <span className="text-[8px] text-[#C5A059] truncate uppercase tracking-tighter">View Source &rarr;</span>
                          </div>
                          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-300 group-hover:text-[#C5A059]"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-100 p-4 rounded-2xl shadow-sm">
                  <div className="flex gap-2">
                    <div className="w-1.5 h-1.5 bg-[#C5A059] rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-[#581819] rounded-full animate-bounce delay-75"></div>
                    <div className="w-1.5 h-1.5 bg-[#1A3C34] rounded-full animate-bounce delay-150"></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSend} className="p-4 border-t border-gray-100 bg-white flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Search trends or ask for advice..."
              className="flex-1 border border-gray-100 bg-gray-50 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-1 focus:ring-[#C5A059] transition-all"
            />
            <button 
              type="submit" 
              disabled={isLoading}
              className="bg-[#1A3C34] text-white p-3 rounded-xl hover:bg-[#581819] disabled:opacity-50 transition-colors shadow-lg"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';

interface NavbarProps {
  cartCount: number;
  onCartClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ cartCount, onCartClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-8'
    }`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className={`flex gap-10 items-center text-[10px] font-bold tracking-[0.4em] uppercase hidden md:flex ${isScrolled ? 'text-black' : 'text-white'}`}>
          <a href="#collections" className="hover:opacity-50 transition-opacity">Collections</a>
          <a href="#shop" className="hover:opacity-50 transition-opacity">Atelier</a>
        </div>

        <a href="/" className="flex flex-col items-center group">
          <div className="flex items-center gap-2">
            <span className={`text-2xl md:text-3xl font-serif font-bold tracking-[0.3em] transition-colors duration-500 ${isScrolled ? 'text-black' : 'text-white'}`}>
              KHAN FABRICS
            </span>
          </div>
          <div className={`h-[1px] w-0 group-hover:w-full transition-all duration-500 ${isScrolled ? 'bg-black' : 'bg-white'}`} />
        </a>

        <div className={`flex gap-8 items-center ${isScrolled ? 'text-black' : 'text-white'}`}>
          <button className="hover:opacity-50 transition-opacity hidden sm:block">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          </button>
          <button onClick={onCartClick} className="relative hover:opacity-50 transition-opacity">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            {cartCount > 0 && (
              <span className={`absolute -top-1 -right-2 text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold ${isScrolled ? 'bg-black text-white' : 'bg-white text-black'}`}>
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </nav>
  );
};
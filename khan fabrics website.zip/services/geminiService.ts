import { GoogleGenAI } from "@google/genai";
import { ChatMessage, Source } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getStylingAdvice = async (history: ChatMessage[], message: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history.map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        })),
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: `You are KHAN AI, the luxury concierge for "KHAN FABRICS", a premium women-only winter wear brand. 
        
        Our Collections: Noor-e-Sard, Zamurd Winter Grace, Riwayat-e-Zanana, Sardiyaan Silhouettes, and Velour Khawab.
        
        When asked for trends or external information, use Google Search to find current luxury fashion context. 
        Always relate external trends back to KHAN FABRICS's aesthetic (Deep Maroon, Bottle Green, Gold accents).
        Tone: Sophisticated and attentive. Provide PKR (Rs.) for internal pricing.`,
        temperature: 0.7,
      }
    });

    const text = response.text || "Welcome to the Khan Fabrics atelier.";
    
    // Extracting URLs from grounding metadata
    const sources: Source[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web && chunk.web.uri && chunk.web.title) {
          sources.push({
            uri: chunk.web.uri,
            title: chunk.web.title
          });
        }
      });
    }

    return { text, sources };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { 
      text: "I'm currently unable to access the atelier archives. Please try again shortly.",
      sources: []
    };
  }
};
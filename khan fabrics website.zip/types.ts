
export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Wool' | 'Pashmina' | 'Velvet' | 'Linen-Wool' | 'Winter';
  collection: string;
  image: string;
  description: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Source {
  uri: string;
  title: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  sources?: Source[];
}
